print 8/0
