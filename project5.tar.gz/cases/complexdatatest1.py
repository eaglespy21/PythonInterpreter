x = 2+2
print x
x += x
print x
x = 2
y = 2
z = x+y
print z

