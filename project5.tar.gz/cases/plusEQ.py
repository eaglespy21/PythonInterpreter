x = 2
y = 2
x+=y
print x
