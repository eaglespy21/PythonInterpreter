print 8**2
