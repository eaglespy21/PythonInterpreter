x = 3.3
y = 2
print x/y
