x = 3.3
print x
