print ---1
