print -9
