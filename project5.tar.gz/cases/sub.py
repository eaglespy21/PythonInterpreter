print 4-5
