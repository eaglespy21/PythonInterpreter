x = 3.3
y = 2.1
print x*y
