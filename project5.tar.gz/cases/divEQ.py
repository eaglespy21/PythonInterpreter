x = 5.5
y = 2.9
x /= y
print x
